Either open mk.py, change the directory to the ORIGINAL csv, and run

OR just see the outputs that i've provided. Open them with Notepad++